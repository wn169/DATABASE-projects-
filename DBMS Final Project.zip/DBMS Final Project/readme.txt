Grocery Inventory Management System

Grocery Inventory Management System is a desktop-based inventory application built using Python Tkinter and Oracle Database. It provides a user-friendly interface to manage products, suppliers, and customers with real-time database integration.

Features

Modern GUI built with Tkinter and ttk

Oracle Database connectivity using oracledb

Tab-based interface for:

Products

Suppliers

Customers

Initialize database directly from an external SQL file

Add new products

Update product prices

Delete products with confirmation

Real-time data refresh

Uses relational joins to display complete product information

Technologies Used

Python 3

Tkinter / ttk (GUI)

Oracle Database (XE)

oracledb Python driver

SQL (DDL & DML)

Database Requirements

Oracle XE installed and running

A valid Oracle user (default used: system)

Required database objects:

Tables: Products, Categories, Suppliers, Customers

Sequence: Products_seq

SQL initialization file:

inventory.sql (must be in the same directory as the Python file)

Installation & Setup

Clone the repository:

git clone https://github.com/your-username/grocery-inventory-management-system.git
cd grocery-inventory-management-system


Install required Python package:

pip install oracledb


Update database credentials in the code:

DB_CONFIG = {
    "user": "system",
    "password": "admin",
    "dsn": "localhost:1521/xe"
}


Ensure inventory.sql exists in the project directory.

Run the application:

python main.py

How It Works

The Initialize DB button executes the SQL script to create tables and sequences.

Data is displayed using Treeview widgets.

CRUD operations interact directly with the Oracle database.

JOIN queries combine Products, Categories, and Suppliers for meaningful output.

Educational Concepts Demonstrated

GUI application development

Oracle database connectivity

SQL JOINs, INSERT, UPDATE, DELETE

Use of sequences in Oracle

Modular Python class design

Exception handling

MVC-style separation (UI + DB logic)

Use Case

This project is suitable for:

Database Systems coursework

Python GUI practice

Oracle SQL integration demos

Academic and portfolio submissions

License

This project is for educational purposes. You may modify and reuse it with proper attribution.