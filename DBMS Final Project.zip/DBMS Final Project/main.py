import tkinter as tk
from tkinter import messagebox, ttk
import oracledb
import os

# --- DATABASE CONFIGURATION ---
DB_CONFIG = {
    "user": "system",
    "password": "admin",
    "dsn": "localhost:1521/xe"
}

class GrocerySystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Nexus Grocery Pro - Inventory Manager")
        self.root.geometry("1100x650")
        
        self.style = ttk.Style()
        self.style.theme_use('clam') 
        
        self.setup_layout()
        
        try:
            self.refresh_all()
        except:
            pass

    def setup_layout(self):
        # --- Top Header ---
        header = tk.Frame(self.root, bg="#2c3e50", height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="GROCERY INVENTORY MANAGEMENT", fg="white", 
                 bg="#2c3e50", font=("Helvetica", 18, "bold")).pack(pady=15)

        # --- Sidebar for Actions ---
        sidebar = tk.Frame(self.root, width=200, bg="#ecf0f1", relief=tk.RAISED)
        sidebar.pack(side=tk.LEFT, fill=tk.Y)

        tk.Label(sidebar, text="CONTROL PANEL", bg="#ecf0f1", 
                 font=("Helvetica", 10, "bold")).pack(pady=20)
        
        # Action Buttons
        actions = [
            ("Initialize DB", self.run_sql_script, "#3498db"),
            ("Refresh Data", self.refresh_all, "#2ecc71"),
            ("Update Price", self.open_price_window, "#e67e22"),
            ("Add Product", self.open_add_product_window, "#9b59b6"),
            ("Delete Product", self.delete_product, "#e74c3c") # New Delete Button
        ]

        for text, cmd, color in actions:
            btn = tk.Button(sidebar, text=text, command=cmd, bg=color, fg="white", 
                            width=18, relief=tk.FLAT, font=("Helvetica", 9, "bold"),
                            activebackground="#34495e", cursor="hand2")
            btn.pack(pady=10, padx=15)

        # --- Main Tabbed Area ---
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.tab_products = self.create_tab("📦 Products", ("ID", "Name", "Category", "Supplier", "Price", "Stock"))
        self.tab_suppliers = self.create_tab("🚚 Suppliers", ("ID", "Name", "Contact", "Phone", "Email"))
        self.tab_customers = self.create_tab("👥 Customers", ("ID", "Name", "Phone", "Email", "Address"))

    def create_tab(self, name, columns):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text=name)
        
        tree = ttk.Treeview(frame, columns=columns, show='headings')
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor=tk.CENTER, width=120)
        
        scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        return tree

    def get_conn(self):
        try:
            return oracledb.connect(**DB_CONFIG)
        except Exception as e:
            messagebox.showerror("Connection Error", f"Cannot connect to Oracle: {e}")
            return None

    def run_sql_script(self):
        if not os.path.exists('inventory.sql'):
            messagebox.showerror("Error", "inventory.sql file not found!")
            return
        conn = self.get_conn()
        if not conn: return
        try:
            cursor = conn.cursor()
            with open('inventory.sql', 'r') as f:
                sql_commands = f.read().replace('/', '').split(';')
            for command in sql_commands:
                clean_cmd = command.strip()
                if clean_cmd: cursor.execute(clean_cmd)
            conn.commit()
            messagebox.showinfo("Success", "Database Initialized!")
            self.refresh_all()
        except Exception as e:
            messagebox.showerror("SQL Error", str(e))
        finally:
            conn.close()

    def refresh_all(self):
        self.load_table(self.tab_products, """
            SELECT p.product_id, p.product_name, c.category_name, s.supplier_name, p.price, p.stock_quantity 
            FROM Products p 
            JOIN Categories c ON p.category_id = c.category_id 
            JOIN Suppliers s ON p.supplier_id = s.supplier_id
            ORDER BY p.product_id
        """)
        self.load_table(self.tab_suppliers, "SELECT supplier_id, supplier_name, contact_name, phone, email FROM Suppliers ORDER BY supplier_id")
        self.load_table(self.tab_customers, "SELECT customer_id, customer_name, phone, email, address FROM Customers ORDER BY customer_id")

    def load_table(self, tree, query):
        conn = self.get_conn()
        if not conn: return
        try:
            cursor = conn.cursor()
            for i in tree.get_children(): tree.delete(i)
            cursor.execute(query)
            for row in cursor: tree.insert("", tk.END, values=row)
        except Exception as e:
            print(f"Data Load Error: {e}")
        finally:
            conn.close()

    # --- ACTION: ADD PRODUCT ---
    def open_add_product_window(self):
        win = tk.Toplevel(self.root)
        win.title("Add New Product")
        win.geometry("400x450")

        fields = ["Product Name", "Category ID", "Supplier ID", "Price", "Stock Quantity"]
        entries = {}

        for field in fields:
            tk.Label(win, text=field + ":", font=("Helvetica", 10)).pack(pady=2)
            ent = tk.Entry(win, width=30)
            ent.pack(pady=5)
            entries[field] = ent

        def submit():
            data = [entries[f].get() for f in fields]
            if any(v == "" for v in data):
                messagebox.showwarning("Input Error", "All fields are required!")
                return
            
            conn = self.get_conn()
            if conn:
                try:
                    cursor = conn.cursor()
                    # We assume product_id is handled by a sequence or you can add it here
                    # Using a sequence: Products_seq.NEXTVAL (Common in Oracle)
                    sql = """INSERT INTO Products (product_id, product_name, category_id, supplier_id, price, stock_quantity) 
                             VALUES (Products_seq.NEXTVAL, :1, :2, :3, :4, :5)"""
                    cursor.execute(sql, data)
                    conn.commit()
                    messagebox.showinfo("Success", "Product Added!")
                    win.destroy()
                    self.refresh_all()
                except Exception as e:
                    messagebox.showerror("DB Error", f"Could not add product: {e}")
                finally:
                    conn.close()

        tk.Button(win, text="Save Product", command=submit, bg="#9b59b6", fg="white", font=("Helvetica", 10, "bold"), width=20).pack(pady=20)

    # --- ACTION: UPDATE PRICE ---
    def open_price_window(self):
        win = tk.Toplevel(self.root)
        win.title("Update Price")
        win.geometry("300x200")
        
        tk.Label(win, text="Product ID:").pack(pady=5)
        id_ent = tk.Entry(win)
        id_ent.pack(pady=5)
        tk.Label(win, text="New Price:").pack(pady=5)
        pr_ent = tk.Entry(win)
        pr_ent.pack(pady=5)
        
        def save():
            conn = self.get_conn()
            if conn:
                cursor = conn.cursor()
                cursor.execute("UPDATE Products SET price = :1 WHERE product_id = :2", (pr_ent.get(), id_ent.get()))
                conn.commit()
                conn.close()
                win.destroy()
                self.refresh_all()
        
        tk.Button(win, text="Update", command=save, bg="#e67e22", fg="white").pack(pady=10)

    # --- ACTION: DELETE PRODUCT ---
    def delete_product(self):
        selected_item = self.tab_products.selection()
        if not selected_item:
            messagebox.showwarning("Selection Error", "Please select a product from the list to delete.")
            return

        # Get Product ID from the first column of the selected row
        product_values = self.tab_products.item(selected_item)['values']
        product_id = product_values[0]
        product_name = product_values[1]

        confirm = messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete '{product_name}' (ID: {product_id})?")
        
        if confirm:
            conn = self.get_conn()
            if conn:
                try:
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM Products WHERE product_id = :1", (product_id,))
                    conn.commit()
                    messagebox.showinfo("Deleted", "Product removed successfully.")
                    self.refresh_all()
                except Exception as e:
                    messagebox.showerror("Error", f"Could not delete: {e}")
                finally:
                    conn.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = GrocerySystem(root)
    root.mainloop()